
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
 class Login
{
    
    boolean checkUsername(String userName)
    {
       
        if(userName.contains("_") && userName.length() <= 5)
        {
            System.out.println("Username Successfully captured!");
            return true;
        }
        else
        {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            return false;
        }
    }
    boolean checkPasswordComplexity(String password)
    {
        boolean length = password.length() >= 8;
        boolean capitalLetter = password.matches(".*[A-Z].*");
        boolean num = password.matches(".*[0-9].*");
        boolean specialChar = password.matches(".*[!@#$%^&*(),.?/:{}|<>].*");
        
        if(length && capitalLetter && num && specialChar)
        {
           System.out.println("Password Successfully captured!");
            return true; 
        }
        else
        {
          System.out.println("Password is not correctly formatted, please ensure that your password contains eight characters in length, a capital letter, a number and a special character.");
            return false;  
        }
    }
    boolean checkCellphoneNumber(String cellNum)
    {
        String regex = "^\\+\\d{1,3}\\d{1,10}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(cellNum);
        
        if(matcher.matches())
        {
            System.out.println("Cellphone Number Successfully added!");
            return true;
        }
        else
        {
            System.out.println("Cellphone Number incorrectly formatted or does not include international code.");
            return false;
        }
    }
    String registerUser(String userName, String password, String cellNum)
        {
          
            boolean validUser = checkUsername(userName);
            boolean validPass = checkPasswordComplexity(password);
            boolean validCell = checkCellphoneNumber(cellNum);
            
            if(validUser && validPass && validCell)
            {
                return "User registered successfully.";
            }
            else
            {
                return "Registration failed. Please check your input.";
            }
        }
    boolean loginUser(String storedUsername, String storedPassword, String enteredUsername, String enteredPassword)
    {
        return storedUsername.equals(enteredUsername) && storedPassword.equals(enteredPassword);
    }
    String returnLoginStatus(boolean loginSuccess, String firstName, String lastName)
    {
        if(loginSuccess)
        {
            return "Welcome "+ firstName +" "+ lastName +", it is great to see you again!";
        }
        else
        {
            return "Username or Password incorrect, please try again.";
        }
    }
}
public class loginAndRegister {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login logAcc = new Login();
        
        System.out.println("====== REGISTRATION ======");
        System.out.print("Enter username: ");
        String userName = scanner.nextLine();
        
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        
        System.out.print("Enter cellphone number (include international code): ");
        String cellNum = scanner.nextLine();
        
        String registrationMessage = logAcc.registerUser(userName, password, cellNum);
        System.out.println(registrationMessage);
        
        if(registrationMessage.equals("User registered successfully."))
        {
          System.out.println("\n====== Login ======");
          System.out.print("Enter username: ");
          String enteredUsername = scanner.nextLine();
          
          System.out.print("Enter password: ");
          String enteredPassword = scanner.nextLine();
          
          boolean loginSuccess = logAcc.loginUser(userName, password, enteredUsername, enteredPassword);
          
          System.out.print("Enter your first name: ");
          String firstName = scanner.nextLine();
          
          System.out.print("Enter your last name: ");
          String lastName = scanner.nextLine();
          
          String loginMessage = logAcc.returnLoginStatus(loginSuccess, firstName, lastName);
          System.out.println(loginMessage);
        }
        scanner.close();
    }
}



