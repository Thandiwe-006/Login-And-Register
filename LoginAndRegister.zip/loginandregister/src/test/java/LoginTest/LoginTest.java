import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class LoginTest {

    Login login = new Login();

    // 🔹 Username Tests
    @Test
    void testValidUsername() {
        assertTrue(login.checkUsername("ab_cd"));
    }

    @Test
    void testInvalidUsername() {
        assertFalse(login.checkUsername("abcd"));
    }

    // 🔹 Password Tests
    @Test
    void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Abcd123!"));
    }

    @Test
    void testInvalidPassword() {
        assertFalse(login.checkPasswordComplexity("abc123"));
    }

    // 🔹 Cellphone Tests
    @Test
    void testValidCellphone() {
        assertTrue(login.checkCellphoneNumber("+27831234567"));
    }

    @Test
    void testInvalidCellphone() {
        assertFalse(login.checkCellphoneNumber("0831234567"));
    }

    // 🔹 Login Tests
    @Test
    void testLoginSuccess() {
        assertTrue(login.loginUser("user_1", "Pass123!", "user_1", "Pass123!"));
    }

    @Test
    void testLoginFailure() {
        assertFalse(login.loginUser("user_1", "Pass123!", "user_2", "Pass123!"));
    }

    // 🔹 Return Login Status
    @Test
    void testReturnLoginStatusSuccess() {
        String message = login.returnLoginStatus(true, "John", "Doe");
        assertEquals("Welcome John Doe, it is great to see you again!", message);
    }

    @Test
    void testReturnLoginStatusFail() {
        String message = login.returnLoginStatus(false, "John", "Doe");
        assertEquals("Username or Password incorrect, please try again.", message);
    }
}